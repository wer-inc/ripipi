import ky from 'ky';
import type { Options } from 'ky';

const API_URL = import.meta.env.VITE_API_URL || 'http://localhost:3000/v1';

class APIClient {
  private ky: typeof ky;

  constructor() {
    this.ky = ky.create({
      prefixUrl: API_URL,
      timeout: 30000,
      retry: {
        limit: 2,
        methods: ['get'],
        statusCodes: [408, 429, 500, 502, 503, 504],
      },
      hooks: {
        beforeRequest: [
          (request) => {
            const token = this.getAuthToken();
            if (token) {
              request.headers.set('Authorization', `Bearer ${token}`);
            }
            request.headers.set('Content-Type', 'application/json');
          },
        ],
        afterResponse: [
          async (request, options, response) => {
            if (!response.ok) {
              const errorData = await response.json().catch(() => ({}));
              
              if (response.status === 401) {
                // Unauthorized - redirect to login
                this.clearAuthToken();
                window.location.href = '/login';
              }
              
              throw new APIError(
                errorData.message || 'An error occurred',
                response.status,
                errorData
              );
            }
            return response;
          },
        ],
      },
    });
  }

  // Auth token management
  private getAuthToken(): string | null {
    return localStorage.getItem('admin_token');
  }

  private setAuthToken(token: string): void {
    localStorage.setItem('admin_token', token);
  }

  private clearAuthToken(): void {
    localStorage.removeItem('admin_token');
  }

  // Generic request methods
  async get<T>(url: string, options?: Options): Promise<T> {
    return this.ky.get(url, options).json<T>();
  }

  async post<T>(url: string, data?: any, options?: Options): Promise<T> {
    return this.ky.post(url, { json: data, ...options }).json<T>();
  }

  async put<T>(url: string, data?: any, options?: Options): Promise<T> {
    return this.ky.put(url, { json: data, ...options }).json<T>();
  }

  async delete<T>(url: string, options?: Options): Promise<T> {
    return this.ky.delete(url, options).json<T>();
  }

  // Auth endpoints
  async login(email: string, password: string) {
    const response = await this.post<{
      success: boolean;
      data: {
        user: any;
        accessToken: string;
        refreshToken: string;
      };
    }>('auth/login', { email, password });
    
    if (response.success && response.data.accessToken) {
      this.setAuthToken(response.data.accessToken);
    }
    
    return response;
  }

  async logout() {
    try {
      await this.post('auth/logout');
    } finally {
      this.clearAuthToken();
    }
  }

  async getCurrentUser() {
    return this.get<{ success: boolean; data: any }>('auth/me');
  }

  // User management
  async getUsers(params?: { page?: number; limit?: number; search?: string }) {
    const searchParams = new URLSearchParams();
    if (params?.page) searchParams.set('page', params.page.toString());
    if (params?.limit) searchParams.set('limit', params.limit.toString());
    if (params?.search) searchParams.set('search', params.search);
    
    return this.get<{ data: any[]; pagination: any }>(`users?${searchParams}`);
  }

  async getUser(id: string) {
    return this.get<{ success: boolean; data: any }>(`users/${id}`);
  }

  async createUser(userData: any) {
    return this.post<{ success: boolean; data: any }>('users', userData);
  }

  async updateUser(id: string, userData: any) {
    return this.put<{ success: boolean; data: any }>(`users/${id}`, userData);
  }

  async deleteUser(id: string) {
    return this.delete<{ success: boolean }>(`users/${id}`);
  }

  // Booking management
  async getBookings(params?: {
    page?: number;
    limit?: number;
    status?: string[];
    startDate?: string;
    endDate?: string;
    customerId?: string;
    serviceId?: string;
    resourceId?: string;
  }) {
    const searchParams = new URLSearchParams();
    if (params?.page) searchParams.set('page', params.page.toString());
    if (params?.limit) searchParams.set('limit', params.limit.toString());
    if (params?.status) params.status.forEach(s => searchParams.append('status', s));
    if (params?.startDate) searchParams.set('startDate', params.startDate);
    if (params?.endDate) searchParams.set('endDate', params.endDate);
    if (params?.customerId) searchParams.set('customerId', params.customerId);
    if (params?.serviceId) searchParams.set('serviceId', params.serviceId);
    if (params?.resourceId) searchParams.set('resourceId', params.resourceId);
    
    return this.get<{ data: any[]; pagination: any }>(`bookings?${searchParams}`);
  }

  async getBooking(id: string) {
    return this.get<{ success: boolean; data: any }>(`bookings/${id}`);
  }

  async createBooking(bookingData: any) {
    return this.post<{ success: boolean; data: any }>('bookings', bookingData);
  }

  async updateBooking(id: string, bookingData: any) {
    return this.put<{ success: boolean; data: any }>(`bookings/${id}`, bookingData);
  }

  async cancelBooking(id: string, reason: string) {
    return this.delete<{ success: boolean; data: any }>(`bookings/${id}`, {
      json: { reason }
    });
  }

  // Service management
  async getServices(params?: { page?: number; limit?: number; isActive?: boolean }) {
    const searchParams = new URLSearchParams();
    if (params?.page) searchParams.set('page', params.page.toString());
    if (params?.limit) searchParams.set('limit', params.limit.toString());
    if (params?.isActive !== undefined) searchParams.set('isActive', params.isActive.toString());
    
    return this.get<{ data: any[]; pagination: any }>(`services?${searchParams}`);
  }

  async getService(id: string) {
    return this.get<{ success: boolean; data: any }>(`services/${id}`);
  }

  async createService(serviceData: any) {
    return this.post<{ success: boolean; data: any }>('services', serviceData);
  }

  async updateService(id: string, serviceData: any) {
    return this.put<{ success: boolean; data: any }>(`services/${id}`, serviceData);
  }

  async deleteService(id: string) {
    return this.delete<{ success: boolean }>(`services/${id}`);
  }

  // Resource management
  async getResources(params?: { page?: number; limit?: number; isActive?: boolean }) {
    const searchParams = new URLSearchParams();
    if (params?.page) searchParams.set('page', params.page.toString());
    if (params?.limit) searchParams.set('limit', params.limit.toString());
    if (params?.isActive !== undefined) searchParams.set('isActive', params.isActive.toString());
    
    return this.get<{ data: any[]; pagination: any }>(`resources?${searchParams}`);
  }

  async getResource(id: string) {
    return this.get<{ success: boolean; data: any }>(`resources/${id}`);
  }

  async createResource(resourceData: any) {
    return this.post<{ success: boolean; data: any }>('resources', resourceData);
  }

  async updateResource(id: string, resourceData: any) {
    return this.put<{ success: boolean; data: any }>(`resources/${id}`, resourceData);
  }

  async deleteResource(id: string) {
    return this.delete<{ success: boolean }>(`resources/${id}`);
  }

  // Timeslot management
  async generateTimeslots(data: {
    resourceId: string;
    startDate: string;
    endDate: string;
    duration: number;
    businessHours: any[];
    buffer?: number;
    skipExisting?: boolean;
  }) {
    return this.post<{ generated: number; updated: number; deleted: number }>(
      'timeslots/generate',
      data
    );
  }

  async getTimeslots(params: {
    serviceId?: string;
    resourceId?: string;
    from: string;
    to: string;
    limit?: number;
    cursor?: string;
  }) {
    const searchParams = new URLSearchParams();
    if (params.serviceId) searchParams.set('service_id', params.serviceId);
    if (params.resourceId) searchParams.set('resource_id', params.resourceId);
    searchParams.set('from', params.from);
    searchParams.set('to', params.to);
    if (params.limit) searchParams.set('limit', params.limit.toString());
    if (params.cursor) searchParams.set('cursor', params.cursor);
    
    return this.get<{ data: any[] }>(`timeslots?${searchParams}`);
  }

  // Availability check
  async checkAvailability(params: {
    serviceId: string;
    startTime: string;
    endTime: string;
    resourceId?: string;
  }) {
    return this.post<{ available: boolean; conflicts: any[] }>('availability/check', params);
  }

  // Payment methods
  async getPaymentMethods(customerId?: string) {
    const url = customerId ? `payment-methods?customerId=${customerId}` : 'payment-methods';
    return this.get<{ data: any[] }>(url);
  }

  async addPaymentMethod(paymentMethodData: any) {
    return this.post<{ success: boolean; data: any }>('payment-methods', paymentMethodData);
  }

  async deletePaymentMethod(id: string) {
    return this.delete<{ success: boolean }>(`payment-methods/${id}`);
  }

  async setDefaultPaymentMethod(id: string) {
    return this.put<{ success: boolean; data: any }>(`payment-methods/${id}/default`);
  }

  // Payments
  async processPayment(paymentData: any) {
    return this.post<{ success: boolean; data: any }>('payments', paymentData);
  }

  async getPayments(params?: {
    page?: number;
    limit?: number;
    bookingId?: string;
    customerId?: string;
    status?: string[];
  }) {
    const searchParams = new URLSearchParams();
    if (params?.page) searchParams.set('page', params.page.toString());
    if (params?.limit) searchParams.set('limit', params.limit.toString());
    if (params?.bookingId) searchParams.set('bookingId', params.bookingId);
    if (params?.customerId) searchParams.set('customerId', params.customerId);
    if (params?.status) params.status.forEach(s => searchParams.append('status', s));
    
    return this.get<{ data: any[]; pagination: any }>(`payments?${searchParams}`);
  }

  async refundPayment(paymentId: string, amount?: number, reason?: string) {
    return this.post<{ success: boolean; data: any }>(`payments/${paymentId}/refund`, {
      amount,
      reason
    });
  }

  // Customer management
  async getCustomers(params?: {
    page?: number;
    limit?: number;
    search?: string;
    status?: string;
  }) {
    const searchParams = new URLSearchParams();
    if (params?.page) searchParams.set('page', params.page.toString());
    if (params?.limit) searchParams.set('limit', params.limit.toString());
    if (params?.search) searchParams.set('search', params.search);
    if (params?.status) searchParams.set('status', params.status);
    
    return this.get<{ data: any[]; pagination: any }>(`customers?${searchParams}`);
  }

  async getCustomer(id: string) {
    return this.get<{ success: boolean; data: any }>(`customers/${id}`);
  }

  async createCustomer(customerData: any) {
    return this.post<{ success: boolean; data: any }>('customers', customerData);
  }

  async updateCustomer(id: string, customerData: any) {
    return this.put<{ success: boolean; data: any }>(`customers/${id}`, customerData);
  }

  async deleteCustomer(id: string) {
    return this.delete<{ success: boolean }>(`customers/${id}`);
  }

  // Settings management
  async getSettings() {
    return this.get<{ success: boolean; data: any }>('settings');
  }

  async updateSettings(settingsData: any) {
    return this.put<{ success: boolean; data: any }>('settings', settingsData);
  }

  async getStoreInfo() {
    return this.get<{ success: boolean; data: any }>('settings/store');
  }

  async updateStoreInfo(storeData: any) {
    return this.put<{ success: boolean; data: any }>('settings/store', storeData);
  }

  async getBookingSettings() {
    return this.get<{ success: boolean; data: any }>('settings/booking');
  }

  async updateBookingSettings(bookingSettings: any) {
    return this.put<{ success: boolean; data: any }>('settings/booking', bookingSettings);
  }

  async getNotificationSettings() {
    return this.get<{ success: boolean; data: any }>('settings/notifications');
  }

  async updateNotificationSettings(notificationSettings: any) {
    return this.put<{ success: boolean; data: any }>('settings/notifications', notificationSettings);
  }

  // Staff management
  async getStaff(params?: { page?: number; limit?: number; isActive?: boolean }) {
    const searchParams = new URLSearchParams();
    if (params?.page) searchParams.set('page', params.page.toString());
    if (params?.limit) searchParams.set('limit', params.limit.toString());
    if (params?.isActive !== undefined) searchParams.set('isActive', params.isActive.toString());
    
    return this.get<{ data: any[]; pagination: any }>(`staff?${searchParams}`);
  }

  async getStaffMember(id: string) {
    return this.get<{ success: boolean; data: any }>(`staff/${id}`);
  }

  async createStaffMember(staffData: any) {
    return this.post<{ success: boolean; data: any }>('staff', staffData);
  }

  async updateStaffMember(id: string, staffData: any) {
    return this.put<{ success: boolean; data: any }>(`staff/${id}`, staffData);
  }

  async deleteStaffMember(id: string) {
    return this.delete<{ success: boolean }>(`staff/${id}`);
  }
}

// Custom error class
export class APIError extends Error {
  constructor(
    message: string,
    public status: number,
    public data?: any
  ) {
    super(message);
    this.name = 'APIError';
  }
}

// Export singleton instance
export const apiClient = new APIClient();

// Export for type usage
export type { APIClient };