/**
 * Migration Template
 * Replace this template with your migration logic
 */

exports.up = pgm => {
  // Add your migration logic here
  // Example:
  // pgm.createTable('example_table', {
  //   id: 'id',
  //   name: { type: 'varchar(255)', notNull: true },
  //   created_at: {
  //     type: 'timestamp',
  //     notNull: true,
  //     default: pgm.func('current_timestamp')
  //   }
  // });
};

exports.down = pgm => {
  // Add your rollback logic here
  // Example:
  // pgm.dropTable('example_table');
};