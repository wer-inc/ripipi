import type { Config } from "drizzle-kit";
export default {
  schema: "./src/db/schema.ts",
  out: "./drizzle",
  dialect: "postgresql",
  dbCredentials: { 
    url: process.env.DATABASE_URL || "postgres://devuser:devpass@localhost:5432/liffapp"
  },
} satisfies Config;